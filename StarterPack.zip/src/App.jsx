export default function App() {
  return <div>Random GIF</div>;
}
